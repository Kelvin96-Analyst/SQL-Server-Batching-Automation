-- This file provides an example of scheduling logic
-- Use SQL Server Agent to run this command every hour:

-- EXEC [dbo].[UpdateBatchStatus] @BatchNumber = 1, @Status = 'In Progress';